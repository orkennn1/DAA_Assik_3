package org.example;

import java.io.*;
import java.util.*;
import org.json.simple.*;
import org.json.simple.parser.JSONParser;

public class Main {

    // Класс ребра
    static class Edge {
        String from, to;
        int weight;

        Edge(String from, String to, int weight) {
            this.from = from;
            this.to = to;
            this.weight = weight;
        }
    }

    // DSU (Union-Find)
    static class DSU {
        Map<String, String> parent = new HashMap<>();
        Map<String, Integer> rank = new HashMap<>();
        int operations = 0;

        public void makeSet(String v) {
            parent.put(v, v);
            rank.put(v, 0);
        }

        public String find(String v) {
            operations++;
            if (!v.equals(parent.get(v))) {
                parent.put(v, find(parent.get(v))); // сжатие путей
            }
            return parent.get(v);
        }

        public boolean union(String a, String b) {
            operations++;
            a = find(a);
            b = find(b);
            if (a.equals(b)) return false;

            if (rank.get(a) < rank.get(b)) {
                String temp = a;
                a = b;
                b = temp;
            }
            parent.put(b, a);
            if (rank.get(a).equals(rank.get(b))) {
                rank.put(a, rank.get(a) + 1);
            }
            return true;
        }
    }

    // Алгоритм Крускала
    static JSONObject kruskal(List<Edge> edges, List<String> nodes) {
        long startTime = System.nanoTime();
        DSU dsu = new DSU();
        for (String node : nodes) dsu.makeSet(node);

        edges.sort(Comparator.comparingInt(e -> e.weight));

        List<JSONObject> mstEdges = new ArrayList<>();
        int totalCost = 0;

        for (Edge e : edges) {
            if (dsu.union(e.from, e.to)) {
                JSONObject edgeObj = new JSONObject();
                edgeObj.put("from", e.from);
                edgeObj.put("to", e.to);
                edgeObj.put("weight", e.weight);
                mstEdges.add(edgeObj);
                totalCost += e.weight;
            }
        }

        long endTime = System.nanoTime();
        double execTimeMs = (endTime - startTime) / 1_000_000.0;

        JSONObject result = new JSONObject();
        result.put("mst_edges", mstEdges);
        result.put("total_cost", totalCost);
        result.put("operations_count", dsu.operations);
        result.put("execution_time_ms", execTimeMs);
        return result;
    }

    // Считывание графов из JSON
    public static void main(String[] args) {
        JSONParser parser = new JSONParser();
        JSONArray resultsArray = new JSONArray();

        try (FileReader reader = new FileReader("input.json")) {
            JSONObject inputObj = (JSONObject) parser.parse(reader);
            JSONArray graphs = (JSONArray) inputObj.get("graphs");

            for (Object gObj : graphs) {
                JSONObject graph = (JSONObject) gObj;
                long id = (long) graph.get("id");
                List<String> nodes = (List<String>) graph.get("nodes");
                JSONArray edgeArray = (JSONArray) graph.get("edges");

                List<Edge> edges = new ArrayList<>();
                for (Object eObj : edgeArray) {
                    JSONObject e = (JSONObject) eObj;
                    edges.add(new Edge(
                            (String) e.get("from"),
                            (String) e.get("to"),
                            ((Long) e.get("weight")).intValue()
                    ));
                }

                JSONObject graphResult = new JSONObject();
                graphResult.put("graph_id", id);

                JSONObject inputStats = new JSONObject();
                inputStats.put("vertices", nodes.size());
                inputStats.put("edges", edges.size());
                graphResult.put("input_stats", inputStats);

                // Запуск Крускала
                JSONObject kruskalResult = kruskal(edges, nodes);
                graphResult.put("kruskal", kruskalResult);

                resultsArray.add(graphResult);
            }

            JSONObject output = new JSONObject();
            output.put("results", resultsArray);

            try (FileWriter file = new FileWriter("output_kruskal.json")) {
                file.write(output.toJSONString());
                System.out.println("✅ Results saved to output_kruskal.json");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

